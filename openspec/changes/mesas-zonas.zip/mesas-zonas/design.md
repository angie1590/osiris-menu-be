## Context

El scaffolding está aplicado y archivado. `modules/mesas` existe como placeholder (router que devuelve `{status: "scaffolding"}`, enums `EstadoZona`/`EstadoMesa` ya definidos). El backend tiene: app FastAPI con `/api/v1`, `db.py` (SQLAlchemy 2 async + asyncpg), `shared/` (envelope de error, excepciones de dominio, dependencia de idempotencia `X-Request-Id`), `auth/levels.py` (`NivelAutorizacion` + `require_nivel` placeholder, D-j), `websocket/` (ConnectionManager + canales `/ws/...`, broadcaster en memoria). El frontend tiene `src/api/apiClient.ts`, `src/ws/wsClient.ts`, `src/modules/mesas/` placeholder, componentes `ui/`, TanStack Query.

§20 es el primer vertical funcional. Construye sobre esos cimientos sin reabrirlos. La restricción central: implementar las reglas REG-20-XX que **no** dependen de §21 Comandas ni §28 Reservas, y dejar el resto como contrato/placeholder explícito.

## Goals / Non-Goals

**Goals:**
- Modelos `Zona`, `Mesa`, `GrupoMesas` + migración `0002`.
- Service con las reglas REG-20-01/02/03/07/08/09/12/14 implementables hoy.
- Endpoints REST de zonas/mesas/grupos con `X-Request-Id` y envelope de error.
- Eventos WS del canal `mesas` con broadcaster testeable.
- Logs auditables de cambios de estado.
- Módulo frontend `mesas` (api/ws/types/hooks/components) + vistas Mesero y Admin.
- Tests backend y frontend según la estrategia de testing.

**Non-Goals:**
- Apertura/cierre real de comanda (§21), reservas (§28), QR público (§32), caja/SRI (§23/§24), cocina/barra (§22), inventario/catálogo/reportes.
- Auth real: se usa el placeholder `require_nivel`; el contrato del endpoint queda correcto aunque la validación de identidad no sea definitiva.
- §31 Configuración: el flag `saltar_estado_por_limpiar` se resuelve con settings temporales (ver D-mz-3), no con el módulo §31.

## Decisions

### D-mz-1 · Reglas como máquina de estados en `service.py`, transición central única
Toda transición de estado de mesa pasa por una función `transicionar_mesa(mesa, nuevo_estado, *, contexto)` que valida REG-20-01 (orígenes válidos para Ocupada), REG-20-07 (zona Inactiva), REG-20-09 (zona En cierre), emite el evento `mesa.estado_cambiado` y escribe el log. Esto centraliza las invariantes y las hace testeables sin endpoints.
- Alternativa descartada: validar en cada endpoint — dispersa las reglas y arriesga inconsistencias.

### D-mz-2 · `comanda_activa_id`/`reserva_activa_id` como columnas sin FK dura todavía
Las tablas `comandas`/`reservas` no existen. Se modelan `comanda_activa_id` y `reserva_activa_id` como `UUID?` **sin** ForeignKey por ahora (se añadirá la FK cuando existan §21/§28), para soportar REG-20-02 como invariante de servicio sin romper la migración. `GrupoMesas.comanda_id` igual: `UUID?` nullable.
- Alternativa descartada: crear FKs a tablas inexistentes — imposible sin §21/§28; forzar tablas vacías sería inventar alcance.
- Riesgo registrado abajo (consistencia futura al añadir las FKs).

### D-mz-3 · Configuración `saltar_estado_por_limpiar` vía settings temporal
§31 no existe. El flag `saltar_estado_por_limpiar` (default `false`, REG-20-07/14 de la reference-spec) se lee de `config.Settings` como `SALTAR_ESTADO_POR_LIMPIAR`. Se documenta como temporal: migrará a §31 cuando exista, sin cambiar el comportamiento.
- Alternativa descartada: tabla de configuración propia de §20 — duplicaría §31; mejor un settings temporal claramente marcado.

### D-mz-4 · Autorización Nivel 2 vía placeholder `require_nivel`, motivo obligatorio en el schema
REG-20-08 (Activa→En cierre) usa `Depends(require_nivel(NivelAutorizacion.NIVEL_2))` (placeholder D-j, hoy no bloquea) y exige `motivo: str` en el body (validado por Pydantic). Así el **contrato** queda correcto y los tests verifican que falta-de-motivo se rechaza; la validación de identidad real llega con la propuesta de auth.
- Alternativa descartada: omitir el nivel hasta tener auth — perdería el contrato y obligaría a retrabajo en endpoints.

### D-mz-5 · Grupos como agrupación lógica; Ocupada+comanda compartida es contrato §21
`POST /grupos` crea el `GrupoMesas`, fija `grupo_id` en cada mesa y valida REG-20-03 (mesa no en otro grupo activo). **No** fuerza las mesas a `Ocupada` ni crea comanda (eso requiere §21). El acoplamiento "todas Ocupadas con una comanda compartida" se documenta como contrato y se implementará en §21. `comanda_id` del grupo queda nulo en esta etapa. Ver PEND-mz-1.

### D-mz-6 · Identificador permanente, baja lógica y QR
`Mesa.id` es `UUID` permanente. `DELETE /mesas/{id}` hace baja lógica (`activa=false`), nunca borra (REG-20-12). El QR (`POST /mesas/{id}/qr`) genera/regenera una URL que codifica el `id` permanente (D-04); el endpoint devuelve la URL/payload del QR, no cambia el `id`. La generación de imagen del QR puede ser un string/URL en esta etapa (la impresión física es de §32).

### D-mz-7 · Eventos WS reutilizan el `ConnectionManager` existente; emisión desde el service
El service llama a un helper de `events.py` que construye el payload tipado (Pydantic) y hace `manager.broadcast("mesas", payload)`. Para testear sin sockets, el broadcaster se inyecta/observa: los tests verifican que el service invoca el broadcast con el payload correcto (manager testeable), además del test de handshake `/ws/mesas` ya existente.

### D-mz-8 · Frontend: hooks TanStack Query sobre el cliente central; reglas solo en backend
`modules/mesas/api.ts` usa el `apiClient` central; `hooks/` exponen `useZonas`, `useMesas`, `useCrearZona`, `useCerrarZona`, `useMarcarLibre`, etc., con invalidación de queries tras mutaciones. Componentes `MesaCard`/`ZonaLayout`/badges/forms son presentacionales. Validación Zod en `MesaForm`/`ZonaForm` es solo UX (formato, requeridos); el backend revalida y decide. Las vistas Mesero/Admin componen estos elementos y manejan loading/empty/error.

## Risks / Trade-offs

- **[Columnas sin FK a comandas/reservas]** → Al implementar §21/§28 se añadirán las FKs vía migración; mientras tanto la integridad de `comanda_activa_id`/`reserva_activa_id` se cuida en el service. Documentado en D-mz-2.
- **[Auth placeholder no bloquea de verdad]** → REG-20-08 Nivel 2 es contrato hasta la propuesta de auth; el riesgo es que en runtime cualquiera cierre una zona. Mitigación: el contrato (dependencia + motivo + log) ya está; se endurece con auth real. Documentado.
- **[Config temporal fuera de §31]** → `SALTAR_ESTADO_POR_LIMPIAR` en settings podría divergir de §31. Mitigación: marcarlo TODO(§31) y centralizar su lectura.
- **[Grupos sin comanda]** → Crear grupo sin Ocupada/comanda puede sorprender a quien espere el comportamiento completo. Mitigación: documentado como contrato §21 (D-mz-5, PEND-mz-1).
- **[Transición automática REG-20-10/11/13 ausente]** → Dependen de §21/§28; quedan como contrato. No se simulan para no inventar alcance.

## Migration Plan

1. Backend: modelos `Zona/Mesa/GrupoMesas` en `models.py`; `alembic revision` → `0002_mesas_zonas` (tablas `zonas`, `mesas`, `grupos_mesas`); `alembic upgrade head` (PG en compose; sqlite en tests).
2. Backend: `schemas.py` (create/update/read + acciones), `service.py` (transición central + reglas), `events.py` (payloads + broadcast), `api.py` (endpoints con `X-Request-Id` e idempotencia).
3. Frontend: `modules/mesas/{api,ws,types}.ts`, hooks, componentes, vistas Mesero/Admin.
4. Tests backend + frontend; `ruff`/`eslint` verdes; `docker compose up --build` levanta los 4 servicios y los endpoints responden.

Rollback: la migración `0002` tiene `downgrade` que elimina las tablas; el módulo vuelve a su estado placeholder revirtiendo los archivos. Sin datos productivos.

## Open Questions

- **PEND-mz-1**: ¿`POST /grupos` debe forzar las mesas a `Ocupada` y crear una comanda compartida ahora, o quedarse como agrupación lógica hasta §21? Recomendación (adoptada en D-mz-5): agrupación lógica ahora; el acoplamiento con comanda se cierra en §21. Si se confirma como regla permanente, formalizar como decisión D-XX.
- **PEND-mz-2**: ¿`usuario_id` en eventos/logs sale de un header temporal (p. ej. `X-Operator-Id`) o queda `null` hasta auth real? Recomendación: aceptar un identificador de operador opcional vía dependencia placeholder y registrar `null` si no se provee, hasta la propuesta de auth.
- **PEND-mz-3**: ¿el QR devuelve solo la URL con el `id`, o también una imagen/representación? Recomendación: solo URL/payload con el `id` permanente en esta etapa; la imagen/impresión física es de §32.
