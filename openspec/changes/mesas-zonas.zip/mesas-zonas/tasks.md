## 1. Backend · modelos y migración

- [ ] 1.1 En `modules/mesas/models.py` definir modelos SQLAlchemy `Zona`, `Mesa`, `GrupoMesas` con sus campos (reference-spec §20); reusar los enums `EstadoZona`/`EstadoMesa` existentes; `comanda_activa_id`/`reserva_activa_id`/`GrupoMesas.comanda_id` como `UUID?` sin FK dura todavía (D-mz-2); `Mesa.activa` para baja lógica
- [ ] 1.2 Importar los modelos de mesas en `migrations/env.py`/registro de metadata; generar migración `0002_mesas_zonas` (tablas `zonas`, `mesas`, `grupos_mesas`) y verificar `alembic upgrade head` / `downgrade`
- [ ] 1.3 Agregar `SALTAR_ESTADO_POR_LIMPIAR` (default `false`) a `config.Settings`, marcado TODO(§31) (D-mz-3)

## 2. Backend · schemas

- [ ] 2.1 `modules/mesas/schemas.py`: schemas Pydantic de Zona (create/update/read), Mesa (create/update/read, filtros `zona_id`/`estado`), GrupoMesas (create/update/read)
- [ ] 2.2 Schemas de acciones: `CerrarZonaRequest` (motivo obligatorio), respuestas de QR; enums expuestos en el contrato con términos canónicos del glosario

## 3. Backend · service (reglas REG-20-XX)

- [ ] 3.1 Función central `transicionar_mesa(...)` que valida REG-20-01 (Ocupada solo desde Libre/Reservada), REG-20-07 (zona Inactiva sin Ocupada/Reservada), REG-20-09 (zona En cierre sin nuevas ocupaciones), emite evento y escribe log (D-mz-1)
- [ ] 3.2 REG-20-02: guard de `comanda_activa_id` (no ocupar mesa con comanda activa) como invariante de servicio
- [ ] 3.3 REG-20-03 + grupos: crear `GrupoMesas` (agrupación lógica), fijar `grupo_id`, rechazar mesa ya en grupo activo; `PATCH /grupos/{id}` agrega mesa con la misma validación; disolución setea `dissolved_at` y limpia `grupo_id` (D-mz-5)
- [ ] 3.4 REG-20-08: `cerrar_zona` exige Nivel 2 (placeholder `require_nivel`) + motivo, transita Activa→En cierre, log auditable; `activar` (Inactiva→Activa) y `desactivar` (→Inactiva solo si la zona no tiene mesas Ocupadas/Reservadas)
- [ ] 3.5 REG-20-12: baja lógica de mesa (`activa=false`), id permanente no reutilizable; QR (`generar/regenerar`) codifica el `id` permanente (D-mz-6)
- [ ] 3.6 REG-20-14: `marcar_libre` (Por limpiar→Libre) por cualquier operador autenticado según `SALTAR_ESTADO_POR_LIMPIAR`
- [ ] 3.7 Hooks de contrato/placeholder documentados para §21/§28 (apertura/cierre de comanda, verificación de reserva, no-show) sin implementarlos

## 4. Backend · API REST

- [ ] 4.1 `modules/mesas/api.py`: routers de zonas (`GET/POST /zonas`, `PATCH /zonas/{id}`, `POST /zonas/{id}/{cerrar,activar,desactivar}`)
- [ ] 4.2 Routers de mesas (`GET/POST /mesas`, `GET/PATCH/DELETE /mesas/{id}`, `POST /mesas/{id}/marcar-libre`, `POST /mesas/{id}/qr`) con filtros `zona_id`/`estado`
- [ ] 4.3 Routers de grupos (`POST /grupos`, `PATCH /grupos/{id}`); todos los mutadores con `Depends(idempotency_guard)` (`X-Request-Id`) y envelope de error del proyecto
- [ ] 4.4 Confirmar que el router de mesas sigue montado bajo `/api/v1` y que los endpoints placeholder previos se reemplazan sin romper rutas

## 5. Backend · WebSocket y eventos

- [ ] 5.1 `modules/mesas/events.py`: payloads tipados (Pydantic) y helpers `emit_mesa_estado_cambiado`, `emit_zona_estado_cambiado`, `emit_grupo_creado`, `emit_grupo_disuelto` que hacen `manager.broadcast("mesas", ...)` (D-mz-7)
- [ ] 5.2 Cablear las emisiones desde el service en cada transición/creación/disolución; payloads con `usuario_id` (placeholder opcional, PEND-mz-2)

## 6. Frontend · módulo mesas (datos)

- [ ] 6.1 `src/modules/mesas/types.ts`: tipos de Zona/Mesa/GrupoMesas y enums de estado (espejo del contrato, sin reglas)
- [ ] 6.2 `src/modules/mesas/api.ts`: funciones sobre el `apiClient` central para zonas/mesas/grupos (incluye acciones cerrar/activar/desactivar/marcar-libre/qr)
- [ ] 6.3 `src/modules/mesas/ws.ts`: suscripción al canal `mesas` vía cliente WS central; tipos de eventos
- [ ] 6.4 `src/modules/mesas/hooks/`: hooks TanStack Query (`useZonas`, `useMesas`, `useCrearZona`, `useCerrarZona`, `useMarcarLibre`, `useCrearMesa`, ...) con invalidación de queries tras mutaciones

## 7. Frontend · componentes y vistas

- [ ] 7.1 Componentes reutilizables: `MesaEstadoBadge`, `ZonaEstadoBadge`, `MesaCard`, `ZonaLayout` (presentacionales, color por estado)
- [ ] 7.2 Formularios `ZonaForm` y `MesaForm` con React Hook Form + Zod (validación de UX)
- [ ] 7.3 Vista **Mesero** (`views/mesero/`): layout de mesas agrupadas por zona usando `ZonaLayout`/`MesaCard`; maneja loading/empty/error
- [ ] 7.4 Vista **Admin** (`views/admin/`): administración de zonas y mesas (crear/editar, cerrar/activar zona, marcar-libre, QR); maneja loading/empty/error; sin reglas de negocio duplicadas

## 8. Tests backend

- [ ] 8.1 Crear zona; crear mesa; mesa inicia en `Libre`
- [ ] 8.2 REG-20-01: Ocupada solo desde Libre/Reservada (acepta desde Libre, rechaza desde Por limpiar)
- [ ] 8.3 REG-20-12: baja lógica conserva el id; id no reutilizable
- [ ] 8.4 REG-20-07: zona Inactiva no admite mesa Ocupada/Reservada
- [ ] 8.5 REG-20-08: Activa→En cierre requiere Nivel 2 + motivo (rechazo sin motivo)
- [ ] 8.6 REG-20-14: Por limpiar→Libre permitido para operador autenticado
- [ ] 8.7 REG-20-03: mesa en grupo activo no puede incluirse en otro grupo
- [ ] 8.8 Endpoints mutadores procesan `X-Request-Id` (duplicado → `409 IDEMPOTENCY_KEY_REUSED`)
- [ ] 8.9 Evento WS se genera al cambiar estado de mesa/zona (broadcaster testeable verifica payload)

## 9. Tests frontend

- [ ] 9.1 Renderizar `ZonaLayout` con zonas/mesas
- [ ] 9.2 `MesaCard` muestra el estado correcto (badge/color)
- [ ] 9.3 Estados loading/empty/error en la vista
- [ ] 9.4 `ZonaForm` valida con Zod (rechaza inválido)
- [ ] 9.5 `MesaForm` valida con Zod (rechaza inválido)
- [ ] 9.6 Hooks llaman al cliente API del módulo (mock de `apiClient`)
- [ ] 9.7 La vista no contiene reglas de negocio complejas duplicadas (consume contrato del backend)

## 10. Verificación y calidad

- [ ] 10.1 Backend: `pytest` verde; `ruff check` + `ruff format --check` verdes
- [ ] 10.2 Frontend: `npm run lint`, `npm run test`, `npm run build` verdes
- [ ] 10.3 `docker compose up --build` levanta los 4 servicios; endpoints `/api/v1/zonas` y `/api/v1/mesas` responden; `/ws/mesas` acepta conexión
- [ ] 10.4 Confirmar criterios: §20 E2E, sin reglas duplicadas en frontend, terminología del glosario, sin ampliar alcance a §21/§22/§23/§24/§26/§28; registrar PEND-mz-1..3 (y elevar a D-XX si alguna se confirma permanente)
