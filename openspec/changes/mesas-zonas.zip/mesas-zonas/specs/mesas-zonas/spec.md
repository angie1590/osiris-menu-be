## ADDED Requirements

### Requirement: Entidades Zona, Mesa y GrupoMesas persistidas

El backend MUST persistir las entidades `Zona`, `Mesa` y `GrupoMesas` de §20 con SQLAlchemy 2 async y una migración Alembic. `Zona` MUST tener `id`, `nombre`, `descripcion?`, `estado`, `aforo_max`, `orden_visualizacion`, `created_at`, `updated_at`. `Mesa` MUST tener `id` (permanente), `zona_id` (mutable), `numero_visible`, `capacidad`, `estado`, `comanda_activa_id?`, `reserva_activa_id?`, `grupo_id?`, `activa`, `created_at`, `updated_at`. `GrupoMesas` MUST tener `id`, `comanda_id?` (nullable hasta §21), `mesas_ids`, `created_at`, `dissolved_at?`.

#### Scenario: Migración crea las tablas

- **WHEN** se aplica `alembic upgrade head`
- **THEN** existen las tablas de `zonas`, `mesas` y `grupos_mesas` con sus columnas

#### Scenario: Crear zona y mesa

- **WHEN** se crea una zona y luego una mesa en esa zona
- **THEN** ambas se persisten y la mesa queda asociada a la zona

### Requirement: Estados canónicos de zona y mesa

`Zona.estado` MUST usar `EstadoZona` (Activa, En cierre, Inactiva) y `Mesa.estado` MUST usar `EstadoMesa` (Libre, Reservada, Ocupada, Por limpiar, Inactiva), con la terminología canónica del glosario. Una mesa creada MUST iniciar en estado `Libre`.

#### Scenario: Mesa nueva inicia Libre

- **WHEN** se crea una mesa en una zona Activa
- **THEN** su estado inicial es `Libre`

### Requirement: REG-20-01 transición a Ocupada solo desde Libre o Reservada

El service MUST permitir transicionar una mesa a `Ocupada` únicamente desde `Libre` o `Reservada`. Cualquier otro origen MUST rechazarse con error de dominio estructurado. La transición real la dispara §21 (apertura de comanda); en esta etapa se expone como operación de servicio con contrato preparado.

#### Scenario: Ocupar desde Libre

- **WHEN** una mesa `Libre` transita a `Ocupada`
- **THEN** la transición se acepta y la mesa queda `Ocupada`

#### Scenario: Ocupar desde Por limpiar se rechaza

- **WHEN** una mesa `Por limpiar` intenta transitar a `Ocupada`
- **THEN** el service rechaza con error de dominio

### Requirement: REG-20-02 una sola comanda activa por mesa

Una `Mesa` MUST NOT tener más de una comanda activa. El modelo MUST exponer `comanda_activa_id` y el service MUST rechazar ocupar una mesa que ya tenga `comanda_activa_id`. La asignación real de comandas pertenece a §21; aquí se valida la invariante como contrato.

#### Scenario: Mesa ya ocupada no acepta segunda comanda

- **WHEN** se intenta ocupar una mesa que ya tiene `comanda_activa_id`
- **THEN** el service rechaza con error de dominio

### Requirement: REG-20-03 grupos de mesas exclusivos

El backend MUST permitir crear un `GrupoMesas` que agrupe 2 o más mesas, registrando `grupo_id` en cada mesa. Una mesa que ya pertenece a un Grupo activo MUST NOT poder incluirse en otro Grupo. En esta etapa el grupo se crea como agrupación lógica; el acoplamiento "todas Ocupadas con comanda compartida" es contrato para §21 y `comanda_id` puede ser nulo.

#### Scenario: Crear grupo con mesas Libres

- **WHEN** se crea un grupo con mesas que no pertenecen a otro grupo activo
- **THEN** el grupo se crea y cada mesa registra su `grupo_id`

#### Scenario: Mesa ya agrupada se rechaza

- **WHEN** se intenta incluir en un nuevo grupo una mesa que ya pertenece a un grupo activo
- **THEN** el service rechaza con error de dominio

### Requirement: REG-20-07 zona Inactiva sin mesas Ocupadas ni Reservadas

Una `Zona` en estado `Inactiva` MUST NOT admitir mesas en estado `Ocupada` ni `Reservada`. El service MUST rechazar transiciones que dejarían una mesa Ocupada/Reservada en una zona Inactiva.

#### Scenario: Ocupar mesa en zona Inactiva se rechaza

- **WHEN** se intenta ocupar una mesa cuya zona está `Inactiva`
- **THEN** el service rechaza con error de dominio

### Requirement: REG-20-08 cierre de zona requiere Nivel 2 y motivo

La transición de zona `Activa` → `En cierre` MUST requerir autorización Nivel 2 y un `motivo` obligatorio. El endpoint correspondiente MUST exigir el motivo y aplicar la dependencia de nivel (placeholder de auth mientras no exista login real). La transición MUST quedar registrada en log auditable.

#### Scenario: Cerrar zona sin motivo se rechaza

- **WHEN** se invoca cerrar una zona sin `motivo`
- **THEN** la operación se rechaza por validación

#### Scenario: Cerrar zona con motivo y Nivel 2

- **WHEN** un operador Nivel 2 cierra una zona Activa con motivo
- **THEN** la zona transita a `En cierre` y queda registrado en log

### Requirement: REG-20-09 zona En cierre rechaza nuevas ocupaciones

Una `Zona` en estado `En cierre` MUST NOT aceptar nuevas ocupaciones de mesa (nuevas comandas/reservas). El service MUST rechazar ocupar/reservar mesas de una zona En cierre. La transición automática a Inactiva al cerrarse la última comanda (REG-20-10) depende de §21 y queda como contrato.

#### Scenario: Ocupar mesa en zona En cierre se rechaza

- **WHEN** se intenta ocupar una mesa cuya zona está `En cierre`
- **THEN** el service rechaza con error de dominio

### Requirement: REG-20-12 identificador de mesa permanente y baja lógica

El `id` de una `Mesa` MUST ser permanente y MUST NOT reutilizarse, incluso tras la baja. `DELETE` de una mesa MUST ser baja lógica (`activa = false`), conservando el registro y su `id`. Una mesa dada de baja MUST NOT poder recrearse reutilizando su identificador.

#### Scenario: Baja lógica conserva el id

- **WHEN** se da de baja una mesa
- **THEN** la mesa queda `activa = false` y su `id` no se reutiliza para una nueva mesa

### Requirement: QR con identificador permanente de mesa

El endpoint de QR MUST generar/regenerar el QR de una mesa codificando su identificador permanente (D-04), sin cambiar el `id`. Regenerar el QR de una mesa MUST producir el mismo identificador lógico.

#### Scenario: Regenerar QR mantiene el identificador

- **WHEN** se regenera el QR de una mesa existente
- **THEN** el identificador codificado es el mismo `id` permanente de la mesa

### Requirement: REG-20-14 Por limpiar → Libre por cualquier operador

La transición `Por limpiar` → `Libre` MUST poder ejecutarla cualquier operador autenticado sin autorización adicional, cuando la configuración lo permite (`saltar_estado_por_limpiar` desactivado implica que el paso existe y es avanzable). El endpoint `marcar-libre` MUST aplicar esta regla.

#### Scenario: Operador marca Por limpiar como Libre

- **WHEN** un operador autenticado marca como `Libre` una mesa en `Por limpiar`
- **THEN** la mesa transita a `Libre`

### Requirement: Endpoints REST de §20 bajo /api/v1

El backend MUST exponer bajo `/api/v1`: `GET/POST /zonas`, `PATCH /zonas/{id}`, `POST /zonas/{id}/cerrar`, `POST /zonas/{id}/activar`, `POST /zonas/{id}/desactivar`, `GET/POST /mesas`, `GET/PATCH/DELETE /mesas/{id}`, `POST /mesas/{id}/marcar-libre`, `POST /mesas/{id}/qr`, `POST /grupos`, `PATCH /grupos/{id}`. Todo endpoint mutador MUST aceptar `X-Request-Id` (idempotencia) y MUST devolver errores con el envelope estructurado del proyecto. `desactivar` una zona MUST exigir que la zona no tenga mesas Ocupadas ni Reservadas.

#### Scenario: Mutador rechaza X-Request-Id duplicado

- **WHEN** se repite una mutación con el mismo `X-Request-Id`
- **THEN** el backend responde `409` `IDEMPOTENCY_KEY_REUSED` sin doble efecto

#### Scenario: Listar mesas filtradas

- **WHEN** se hace `GET /api/v1/mesas?zona_id=&estado=`
- **THEN** se devuelven las mesas que cumplen el filtro

### Requirement: Eventos WebSocket del canal mesas

Los cambios de estado de mesa y zona y la creación/disolución de grupos MUST emitir eventos por el canal lógico `mesas` (ruta física `/ws/mesas`): `mesa.estado_cambiado` (`{ mesa_id, estado_anterior, estado_nuevo, comanda_id?, timestamp, usuario_id }`), `zona.estado_cambiado` (`{ zona_id, estado_anterior, estado_nuevo, timestamp, usuario_id }`), `grupo.creado` / `grupo.disuelto` (`{ grupo_id, mesas_ids, comanda_id?, timestamp, usuario_id }`). MUST NOT usarse Socket.IO. Los payloads MUST ser tipados y emitidos por un broadcaster testeable.

#### Scenario: Cambio de estado de mesa emite evento

- **WHEN** una mesa cambia de estado a través del service
- **THEN** se emite `mesa.estado_cambiado` por el canal `mesas` con el payload tipado

#### Scenario: Crear grupo emite evento

- **WHEN** se crea un grupo de mesas
- **THEN** se emite `grupo.creado` con `mesas_ids`

### Requirement: Logs auditables de cambios de estado

Todo cambio de estado de mesa o de zona MUST generar un log auditable (append-only) con usuario, timestamp y motivo cuando aplique (Principio 1).

#### Scenario: Cierre de zona queda en log

- **WHEN** una zona transita `Activa` → `En cierre` con motivo
- **THEN** se registra un log con usuario, timestamp y motivo

### Requirement: Módulo frontend de mesas sin reglas de negocio duplicadas

El frontend MUST implementar `src/modules/mesas/` con `api.ts` (vía cliente Axios central de `src/api/`), `ws.ts` (canal `mesas`), `types.ts`, hooks de TanStack Query y los componentes reutilizables `MesaCard`, `ZonaLayout`, `MesaEstadoBadge`, `ZonaEstadoBadge`, `MesaForm`, `ZonaForm`. Debe proveer una **vista Mesero** (layout de mesas agrupadas por zona) y una **vista Admin** (administración de zonas y mesas). Los formularios MUST usar React Hook Form + Zod (validación de UX). El frontend MUST NOT duplicar reglas de negocio del dominio: la autoridad es el backend.

#### Scenario: Vista Mesero muestra mesas por zona

- **WHEN** se renderiza la vista Mesero con datos de zonas y mesas
- **THEN** se muestran las mesas agrupadas por zona con su estado visible

#### Scenario: Formularios validan con Zod

- **WHEN** se envía un formulario de zona o mesa con datos inválidos
- **THEN** la validación Zod impide el envío y muestra errores accionables

#### Scenario: Estados de carga/vacío/error

- **WHEN** la carga de datos está pendiente, vacía o falla
- **THEN** la vista muestra el estado loading, empty o error correspondiente

### Requirement: Integración con Comandas y Reservas como contrato preparado

La integración real con §21 Comandas (apertura/cierre, Ocupada+comanda de grupo, REG-20-06/10) y §28 Reservas (verificación REG-20-05, no-show REG-20-13, reactivación REG-20-11) MUST quedar como contrato/placeholder documentado y MUST NOT implementarse en esta propuesta. Las columnas `comanda_activa_id`, `reserva_activa_id` y `GrupoMesas.comanda_id` MUST existir para soportar la integración futura sin migración disruptiva.

#### Scenario: Columnas de integración presentes sin lógica de comandas/reservas

- **WHEN** se inspeccionan los modelos de §20
- **THEN** existen `comanda_activa_id`, `reserva_activa_id` y `GrupoMesas.comanda_id` sin lógica de apertura/cierre de comanda ni de reservas
