## Why

El scaffolding inicial ya está aplicado, verificado y archivado (`backend-foundation`, `frontend-foundation`, `realtime-foundation`, `mvp-modules-scaffolding`, `workspace-orchestration`). §20 Mesas y zonas es el **módulo fundacional** del MVP: las comandas se abren sobre mesas, los meseros operan sobre mesas y las reservas se asignan a mesas. Construirlo de punta a punta primero desbloquea §21 Comandas y §22 Cocina/barra sobre un contrato real.

Esta propuesta convierte el placeholder de `modules/mesas` en el **primer vertical funcional** (backend + frontend + WebSocket), implementando las reglas críticas de `openspec/reference-specs/20-mesas.md` y dejando como contrato/placeholder explícito todo lo que depende de §21 Comandas y §28 Reservas (aún no implementados).

## What Changes

- **Modelos backend**: `Zona`, `Mesa`, `GrupoMesas` (SQLAlchemy 2 async) con sus campos de la reference-spec, más migración Alembic. Reusa los enums canónicos ya existentes (`EstadoZona`, `EstadoMesa`).
- **Service layer §20** con las reglas REG-20-XX implementables sin §21/§28: transición de mesa (REG-20-01), unicidad de comanda activa como guard de contrato (REG-20-02), grupos (REG-20-03), zona Inactiva sin mesas Ocupadas/Reservadas (REG-20-07), Activa→En cierre Nivel 2 + motivo (REG-20-08), zona En cierre rechaza nuevas ocupaciones (REG-20-09 parcial), identificador permanente y baja lógica (REG-20-12), Por limpiar→Libre por cualquier operador si la config lo permite (REG-20-14).
- **Endpoints REST** bajo `/api/v1` para zonas, mesas y grupos (CRUD + acciones de estado), todos los mutadores con `X-Request-Id` (idempotencia) y errores estructurados del proyecto.
- **Eventos WebSocket** en el canal lógico `mesas` (ruta física `/ws/mesas`): `mesa.estado_cambiado`, `zona.estado_cambiado`, `grupo.creado`, `grupo.disuelto`, con payload tipado y broadcaster testeable.
- **Logs auditables** de todo cambio de estado de mesa y zona (Principio 1).
- **Frontend `modules/mesas`**: `api.ts`, `ws.ts`, `types.ts`, hooks TanStack Query, componentes reutilizables (`MesaCard`, `ZonaLayout`, `MesaEstadoBadge`, `ZonaEstadoBadge`, `MesaForm`, `ZonaForm`) y dos vistas: Mesero (layout de mesas por zona) y Admin (administración de zonas/mesas). Formularios con React Hook Form + Zod. Sin reglas de negocio duplicadas.
- **Tests**: backend (reglas REG-20-XX, idempotencia, evento WS) y frontend (render, estados loading/empty/error, validación Zod, hooks → cliente API).
- **Graduación de scaffolding**: `modules/mesas` deja de ser placeholder. La requirement "routers placeholder sin reglas de negocio" de `mvp-modules-scaffolding` se acota a los módulos aún en scaffolding (`comandas`, `cocina_barra`).
- **Normalización de identificadores**: se usan los identificadores canónicos `REG-20-XX` (la reference-spec ya los usa; no hay `R-MESA-XX` que migrar). Sin cambios de significado.

## Capabilities

### New Capabilities
- `mesas-zonas`: gestión completa de zonas, mesas y grupos de mesas (§20): entidades, estados, reglas REG-20-XX implementables sin §21/§28, endpoints REST, eventos WebSocket del canal `mesas`, y el módulo frontend con vistas Mesero/Admin.

### Modified Capabilities
- `mvp-modules-scaffolding`: la requirement de routers placeholder se acota a los módulos todavía en scaffolding (`comandas`, `cocina_barra`); §20 queda implementado por `mesas-zonas`.

## Impact

- **Backend nuevo/cambiado**: `src/osiris/modules/mesas/{models,schemas,service,api,events}.py` (de placeholder a funcional), nueva migración Alembic `0002_mesas_zonas`, registro de router ya existente bajo `/api/v1`.
- **Frontend nuevo/cambiado**: `osiris-menu-fe/src/modules/mesas/**` (api/ws/types/hooks/components), vistas `views/mesero/` y `views/admin/`, componentes reutilizables nuevos en `src/components/`.
- **Contratos preparados (no implementados)**: integración con §21 Comandas (apertura/cierre, `comanda_activa_id`, Ocupada+comanda de grupo) y §28 Reservas (`reserva_activa_id`, verificación, no-show) quedan como columnas + hooks de servicio + placeholders documentados.
- **Dependencias externas**: ninguna nueva. Stack y Docker Compose sin cambios estructurales; el compose debe seguir levantando los cuatro servicios.
- **Fuera de alcance**: apertura/cierre real de comanda, reservas completas, QR público completo, facturación, caja, cocina/barra, inventario, catálogo, reportes y auth completo de roles (se usa el placeholder `require_nivel` de `auth`).
