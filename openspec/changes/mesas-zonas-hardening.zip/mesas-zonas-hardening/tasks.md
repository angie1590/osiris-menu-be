## 1. Backend · validaciones y reactivación

- [ ] 1.1 `schemas.py`: `MesaCreate.capacidad`/`MesaUpdate.capacidad` con `Field(ge=1)` (capacidad positiva, REG-20-17); quitar default 0 donde aplique
- [ ] 1.2 `service.crear_mesa`: validar `zona.estado == activa` (rechazar `inactiva`/`en_cierre`, `ZONA_NO_ACTIVA`, REG-20-16) y unicidad de `numero_visible` en la zona incluyendo inactivas (`NUMERO_VISIBLE_DUPLICADO`, REG-20-15)
- [ ] 1.3 `service.actualizar_mesa`: si cambia `numero_visible` o `zona_id`, revalidar unicidad por zona (REG-20-15)
- [ ] 1.4 `service.baja_mesa`: rechazar si `ocupada`/`reservada`/agrupada/`comanda_activa_id` (`MESA_NO_DESACTIVABLE`, REG-20-18); mantener baja lógica; audit `mesa.baja_logica`; emitir evento de mesa
- [ ] 1.5 `service.reactivar_mesa` (nuevo): requiere `activa == false` y zona `activa`; pasa a `libre` vía `transicionar_mesa`; audit `mesa.reactivada` (REG-20-19)
- [ ] 1.6 `events.py`: helpers/payloads para `mesa.desactivada` y `mesa.reactivada` (o reutilizar `mesa.estado_cambiado` documentando)

## 2. Backend · API y migración

- [ ] 2.1 `api.py`: `POST /mesas/{id}/reactivar` (con `X-Request-Id`, `current_operator`, envelope de error)
- [ ] 2.2 Verificar que `DELETE /mesas/{id}` (desactivar) propaga las nuevas validaciones de REG-20-18
- [ ] 2.3 `models.py`: `UniqueConstraint("zona_id", "numero_visible")` en `Mesa`; migración `0003_mesa_numero_visible_unico` (add/drop constraint); `alembic upgrade head`/`downgrade`

## 3. Frontend · componentes shadcn y toasts

- [ ] 3.1 Agregar componentes shadcn en `src/components/ui/`: `card`, `badge`, `alert`, `dialog` (Tailwind + cva; dialog sobre `@radix-ui/react-dialog`)
- [ ] 3.2 Agregar `sonner` (toaster) y montarlo una vez en `main.tsx`; helper para mostrar errores de mutación como toast
- [ ] 3.3 Actualizar `package.json`/lock con `@radix-ui/react-dialog` y `sonner` (justificadas en design); `npm ci` sigue funcionando

## 4. Frontend · módulo mesas (datos/UX)

- [ ] 4.1 `modules/mesas/api.ts` + `hooks`: `reactivarMesa` / `useReactivarMesa`; `bajaMesa` ya existe → `useDesactivarMesa` con invalidación
- [ ] 4.2 Helper `esAgrupable(mesa)` = `estado === "libre" && activa && grupo_id == null` (prevención UX, no regla de negocio; REG-20-20)
- [ ] 4.3 `MesaForm`: zod `capacidad` positiva (`>= 1`) y `numero_visible` requerido; `ZonaForm` mantiene validaciones

## 5. Frontend · rediseño vista Admin

- [ ] 5.1 Reescribir `views/admin/Admin.tsx` con Card/Badge/Alert/Dialog + Tailwind (sin HTML plano); estados loading/empty/error
- [ ] 5.2 Acciones contextuales de zona (REG-20-21): `inactiva` → "Activar"; `activa` → acciones válidas; `en_cierre` → estado + acciones válidas
- [ ] 5.3 Formulario "Nueva mesa" sólo en zonas `activa`; mensaje informativo en `inactiva`/`en_cierre`
- [ ] 5.4 Acciones de mesa: "Activar" (mesa inactiva + zona activa), "Desactivar" (mesa elegible), QR (Dialog "Ver QR"/"Copiar URL", REG-20-22), "Separar grupo" para mesas agrupadas; deshabilitar con explicación cuando no apliquen
- [ ] 5.5 Selección para unir sólo sobre mesas agrupables; checkbox deshabilitado/no disponible para el resto; botón "Unir mesas" deshabilitado hasta 2+ válidas con ayuda (REG-20-20)
- [ ] 5.6 Errores backend como toast/alert contextual (no banda cruda global)

## 6. Tests backend

- [ ] 6.1 Crear dos mesas con mismo `numero_visible` en la misma zona → falla; en zonas distintas → ok
- [ ] 6.2 Crear mesa en zona `inactiva` → falla; en `en_cierre` → falla
- [ ] 6.3 Crear mesa con `capacidad = 0` → falla (422)
- [ ] 6.4 Agrupar mesa `inactiva`/`por_limpiar`/`ocupada`/`reservada`/ya agrupada → falla; unir requiere 2+ válidas
- [ ] 6.5 Desactivar mesa `ocupada`/`reservada`/agrupada/con `comanda_activa_id` → falla
- [ ] 6.6 Desactivar mesa válida → baja lógica + audit log
- [ ] 6.7 Reactivar mesa en zona `activa` → `libre`; en zona `inactiva`/`en_cierre` → falla
- [ ] 6.8 Reactivar/desactivar registran audit log; QR usa `mesa.id`; mutadores mantienen `X-Request-Id`; errores con envelope estructurado

## 7. Tests frontend

- [ ] 7.1 No permite seleccionar mesas `inactiva`/`por_limpiar`/`ocupada`/`reservada`/agrupadas para unir
- [ ] 7.2 Botón "Unir mesas" disabled con <2 válidas; enabled con 2+ libres válidas
- [ ] 7.3 Zona `inactiva` muestra "Activar" y no "Desactivar"; `activa`/`en_cierre` muestran acciones válidas
- [ ] 7.4 No aparece formulario "Nueva mesa" en zona `inactiva` ni `en_cierre`
- [ ] 7.5 Mesa muestra acción QR; mesa `inactiva` (zona activa) muestra "Activar"; mesa agrupada muestra indicador + "Separar grupo"
- [ ] 7.6 Errores backend se muestran como toast/alert consistente
- [ ] 7.7 `MesaForm` valida `numero_visible` requerido y capacidad positiva; UI sin reglas complejas duplicadas; usa componentes reutilizables (no HTML plano)

## 8. Documentación · riesgos residuales

- [ ] 8.1 Crear `openspec/known-risks.md` con pendientes controlados: vistas placeholder (Cocina/Barra §22, Caja §23, Público QR §32); e2e multi-módulo (tras §20+§21+§22); auth real (`usuario_id` placeholder); retención de `audit_logs` (antes de producción); agrupar `por_limpiar` requiere D-XX nueva
- [ ] 8.2 No mezclar los riesgos con reglas implementadas; dejarlos como seguimiento, no como tareas de esta corrección

## 9. Verificación y calidad

- [ ] 9.1 Backend: `pytest` verde; `ruff check` + `ruff format --check` verdes
- [ ] 9.2 Frontend: `npm run lint`, `npm run test`, `npm run build` verdes
- [ ] 9.3 `docker compose up --build` levanta los 4 servicios; migración `0003` aplicada; endpoints (incl. `POST /mesas/{id}/reactivar`) y `/ws/mesas` responden
- [ ] 9.4 Confirmar criterios: validaciones backend como autoridad, UI previene errores obvios sin duplicar reglas, Admin alineada al stack visual, riesgos residuales registrados, sin ampliar alcance a módulos futuros
